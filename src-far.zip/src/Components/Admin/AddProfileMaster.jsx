// src/pages/.../AddProfileMaster.jsx
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { RiSearchLine } from "react-icons/ri";
import axios from "axios";
import Draggable from "react-draggable";
import { viewInvestigations, addProfile } from "../../services/apiService"; // keep this if you export addProfile

const AddProfileMaster = () => {
  const [profiles, setProfiles] = useState([]);
  const [selectedProfile, setSelectedProfile] = useState("");
  const [investigations, setInvestigations] = useState([]);
  const [filteredInvestigations, setFilteredInvestigations] = useState([]);
  const [search, setSearch] = useState("");
  const [selectedTests, setSelectedTests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  const navigate = useNavigate();

  // Fetch Profile Entries
  useEffect(() => {
    const fetchProfiles = async () => {
      try {
        const token = localStorage.getItem("authToken");
        const response = await axios.get(
          "https://asrlabs.asrhospitalindia.in/lims/master/get-profileentry",
          {
            headers: { Authorization: `Bearer ${token}` },
            params: { page: 1, limit: 100 },
          }
        );
        // adapt if your API uses response.data.data or response.data
        setProfiles(response.data?.data || response.data || []);
      } catch (err) {
        console.error("Failed to fetch profiles", err);
        setProfiles([]);
      }
    };
    fetchProfiles();
  }, []);

  // Fetch Investigations
  useEffect(() => {
    const fetchInvestigations = async () => {
      try {
        const params = { page: 1, limit: 1000 };
        const response = await viewInvestigations(params);
        // handle both axios response and direct array
        const arr = response?.data || response || [];
        const data = Array.isArray(arr)
          ? arr.sort(
              (a, b) => Number(a.investigation_id) - Number(b.investigation_id)
            )
          : Array.isArray(arr?.data)
          ? arr.data.sort(
              (a, b) => Number(a.investigation_id) - Number(b.investigation_id)
            )
          : [];
        setInvestigations(data);
        setFilteredInvestigations(data);
      } catch (err) {
        console.error("Failed to fetch investigations", err);
        setInvestigations([]);
        setFilteredInvestigations([]);
      } finally {
        setLoading(false);
      }
    };
    fetchInvestigations();
  }, []);

  const handleProfileChange = (e) => {
    setSelectedProfile(e.target.value);
    setSelectedTests([]);
  };

  const addTest = (test) => {
    if (!selectedTests.some((t) => t.name === test)) {
      setSelectedTests((prev) => [...prev, { name: test }]);
    }
  };

  const removeTest = (test) => {
    setSelectedTests((prev) => prev.filter((t) => t.name !== test));
  };

  const handleReset = () => {
    setSelectedProfile("");
    setSelectedTests([]);
    setSearch("");
  };

  useEffect(() => {
    if (!search.trim()) {
      setFilteredInvestigations(investigations);
    } else {
      const lower = search.toLowerCase();
      setFilteredInvestigations(
        investigations.filter((inv) =>
          (inv.testname || "").toLowerCase().includes(lower)
        )
      );
    }
  }, [search, investigations]);

  const handleAddProfile = async () => {
    if (!selectedProfile) {
      alert("Please select a profile name.");
      return;
    }
    if (selectedTests.length === 0) {
      alert("Please add at least one test to the profile.");
      return;
    }

    setIsSubmitting(true);

    try {
      const payload = {
        profilename: selectedProfile,
        tests: selectedTests.map((t) => ({ testname: t.name })),
      };

      // call the helper from apiService (expected to return axios response or data)
      const res = await addProfile(payload);

      // robust success detection for different shapes of response
      const ok =
        (res && (res.status === 200 || res.status === 201)) ||
        (res &&
          res.data &&
          (res.data.status === 200 || res.data.status === 201)) ||
        (res && res.success === true) ||
        (res &&
          typeof res === "object" &&
          res.message &&
          /success/i.test(res.message));

      if (ok) {
        setShowSuccessModal(true);
        handleReset();
      } else {
        // if apiService returns response.data only, maybe check that:
        if (
          res &&
          res.data &&
          (res.data.success === true || /success/i.test(res.data.message || ""))
        ) {
          setShowSuccessModal(true);
          handleReset();
        } else {
          throw new Error("Failed to add profile");
        }
      }
    } catch (err) {
      console.error(err);
      alert(
        err?.response?.data?.message ||
          err.message ||
          "Failed to add profile. Please try again."
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const closeSuccessModal = () => {
    setShowSuccessModal(false);
    navigate("/view-profile");
  };

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      {/* Breadcrumb */}
      <div className="fixed top-[61px] w-full z-10">
        <nav
          className="flex items-center font-medium justify-start px-4 py-2 bg-gray-50 border-b shadow-lg"
          aria-label="Breadcrumb"
        >
          <ol className="inline-flex items-center space-x-1 md:space-x-3 text-sm font-medium">
            <li>
              <Link to="/" className="text-gray-700 hover:text-teal-600">
                🏠 Home
              </Link>
            </li>
            <li className="text-gray-400">/</li>
            <li>
              <span className="text-gray-700">Profile Master</span>
            </li>
            <li className="text-gray-400">/</li>
            <li aria-current="page" className="text-gray-500">
              Add Profile
            </li>
          </ol>
        </nav>
      </div>

      {/* Form Container */}
      <div className="w-full mt-16">
        <div className="bg-white shadow-lg rounded-xl border border-gray-200 overflow-hidden">
          <div className="border-b border-gray-200 px-6 py-4 bg-gradient-to-r from-teal-600 to-teal-500">
            <h4 className="font-semibold text-white">Add New Profile</h4>
          </div>

          <div className="p-6 space-y-6">
            {/* Profile Selection */}
            <div className="space-y-1 w-1/2">
              <label className="block text-sm font-medium text-gray-700">
                Profile Entry Name
              </label>
              <select
                value={selectedProfile}
                onChange={handleProfileChange}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
              >
                <option value="">-- Select Profile --</option>
                {profiles.map((p) => (
                  <option key={p.id} value={p.profilename}>
                    {p.profilename}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Available Investigations */}
              <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                <div className="flex justify-between items-center mb-2">
                  <h2 className="text-sm font-semibold text-gray-700">
                    List of Investigations
                  </h2>
                  <div className="relative w-48">
                    <input
                      type="text"
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      className="w-full pl-10 pr-4 py-1 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none text-sm"
                      placeholder="Search..."
                    />
                    <RiSearchLine className="absolute left-2 top-1.5 text-gray-400" />
                  </div>
                </div>

                {loading ? (
                  <p className="text-center text-gray-500 py-6">Loading...</p>
                ) : filteredInvestigations.length === 0 ? (
                  <p className="text-center text-gray-500 py-6">
                    No Investigations found.
                  </p>
                ) : (
                  <ul className="space-y-2 max-h-64 overflow-y-auto border rounded-lg p-2 text-sm">
                    {filteredInvestigations.map((inv, idx) => (
                      <li
                        key={`${inv.investigation_id || idx}`}
                        className="flex justify-between items-center p-2 border-b last:border-0"
                      >
                        <span>{inv.testname}</span>
                        <button
                          onClick={() => addTest(inv.testname)}
                          className="px-2 py-1 text-xs bg-teal-100 text-teal-700 rounded hover:bg-teal-200"
                        >
                          Add
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              {/* Selected Tests */}
              <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                <h2 className="text-sm font-semibold text-gray-700 mb-2">
                  Selected Tests
                </h2>
                {selectedTests.length === 0 ? (
                  <p className="text-gray-400 text-sm">No tests selected.</p>
                ) : (
                  <ul className="space-y-2 max-h-64 overflow-y-auto">
                    {selectedTests.map((test, idx) => (
                      <li
                        key={`${test.name}-${idx}`}
                        className="flex items-center justify-between gap-2 p-2 border rounded-lg"
                      >
                        <p className="font-medium text-sm">{test.name}</p>
                        <button
                          onClick={() => removeTest(test.name)}
                          className="px-2 py-1 text-xs bg-red-100 text-red-600 rounded hover:bg-red-200"
                        >
                          ✕
                        </button>
                      </li>
                    ))}
                  </ul>
                )}

                {/* Buttons */}
                <div className="mt-6 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={handleReset}
                    className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition"
                  >
                    Reset
                  </button>
                  <button
                    type="button"
                    onClick={handleAddProfile}
                    disabled={isSubmitting}
                    className="px-6 py-2 bg-gradient-to-r from-teal-600 to-teal-500 text-white rounded-lg shadow-md hover:from-teal-700 hover:to-teal-600 transition-all duration-300 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-teal-500 disabled:opacity-70 disabled:cursor-not-allowed"
                  >
                    {isSubmitting ? "Processing..." : "Add Profile"}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Draggable Success Modal */}
      {showSuccessModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
          <Draggable handle=".drag-handle" bounds="parent">
            <div className="w-11/12 sm:w-96 bg-white rounded-lg shadow-lg">
              {/* header - this is the drag handle */}
              <div className="drag-handle cursor-move bg-gradient-to-r from-green-600 to-green-500 text-white px-4 py-3 rounded-t-lg flex items-center justify-between">
                <span className="font-semibold">Profile Added</span>
                <button
                  onClick={() => setShowSuccessModal(false)}
                  className="text-white hover:opacity-90"
                  aria-label="close"
                >
                  ✕
                </button>
              </div>

              <div className="p-6 text-center">
                <h3 className="text-lg font-semibold text-green-600 mb-4">
                  Profile Added Successfully!
                </h3>
                <button
                  onClick={closeSuccessModal}
                  className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition"
                >
                  OK
                </button>
              </div>
            </div>
          </Draggable>
        </div>
      )}
    </div>
  );
};

export default AddProfileMaster;
