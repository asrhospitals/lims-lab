import React from "react";

const HomeLayout = () => {
  return <div>HomeLayout</div>;
};

export default HomeLayout;
