import React from 'react'

function UpdateAccessionMaster() {
  return (
    <div>
      UpdateAccessionMaster
    </div>
  )
}

export default UpdateAccessionMaster
