import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useNavigate, Link } from "react-router-dom";

const AddUserMapping = () => {

  const [fetchError, setFetchError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();
  const [hospitalsList, setHospitalsList] = useState([]);
  const [nodalsList, setNodalsList] = useState([]);
  const [rolesList, setRolesList] = useState([]);


  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    trigger,
  } = useForm({ mode: "onBlur" });

  // Get today's date (to restrict DOB)
  const today = new Date().toISOString().split("T")[0];


  useEffect(() => {
    const fetchHospitals = async () => {
      try {
        const token = localStorage.getItem("authToken");
  
        const res = await fetch(
          "https://asrlabs.asrhospitalindia.in/lims/master/get-hospital?page=1&limit=1000",
          {
            method: "GET",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${token}`,
            },
          }
        );
  
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
  
        const data = await res.json();
        console.log("data===", data);
  
        const options = data.data.map(hospital => ({
          value: hospital.id,
          label: hospital.hospitalname, // use correct key
        }));
  
        setHospitalsList(options);
      } catch (error) {
        console.error("Failed to fetch hospitals", error);
      }
    };
  
    fetchHospitals();
  }, []);
  
  
  
useEffect(() => {
  const fetchNodals = async () => {
    try {
      const token = localStorage.getItem("authToken");

      const res = await fetch(
        "https://asrlabs.asrhospitalindia.in/lims/master/get-nodal?page=1&limit=1000",
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`,
          },
        }
      );

      if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);

      const data = await res.json();
      console.log("Nodals data===", data);

      // Assuming the API returns nodals in data.data and nodals have id and name
      const options = data.data.map(nodal => ({
        value: nodal.id,
        label: nodal.nodalname || "Unknown Nodal", // adjust key based on actual response
      }));

      setNodalsList(options);
    } catch (error) {
      console.error("Failed to fetch nodals", error);
    }
  };

  fetchNodals();
}, []);


useEffect(() => {
  const fetchRoles = async () => {
    try {
      const token = localStorage.getItem("authToken");

      const res = await fetch(
        "https://asrlabs.asrhospitalindia.in/lims/master/get-role",
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`,
          },
        }
      );

      if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);

      const data = await res.json();
      console.log("Roles data===", data); // <--- check this in browser console

      // Map roles based on the actual key from the API response
      const options = data.data.map(role => ({
        value: role.id,
        label: role.role_name || role.name || Object.values(role)[0], 
        // use the correct key after checking console log
      }));

      setRolesList(options);
    } catch (error) {
      console.error("Failed to fetch roles", error);
    }
  };

  fetchRoles();
}, []);


  const onSubmit = async (data) => {
    setIsSubmitting(true);
    //     try {
    //       const payload = {
    //         phleboname: data.phleboname,
    //         addressline: data.addressline,
    //         city: data.city,
    //         state: data.state,
    //         pincode: Number(data.pincode),
    //         dob: data.dob,
    //         contactno: data.contactno.toString(),
    //         gender: data.gender,
    //         isactive: data.isactive === "true",
    //       };

    //       console.log("payload ===", payload);

    //       const authToken = localStorage.getItem("authToken");

    //       await axios.post(
    //         "https://asrlabs.asrhospitalindia.in/lims/master/add-phlebo",
    //         payload,
    //         {
    //           headers: {
    //             Authorization: `Bearer ${authToken}`,
    //           },
    //         }
    //       );

    //       toast.success("New Phlebotomist added successfully!");
    //       reset();
    //       setTimeout(() => navigate("/view-phlebotomist"), 1500);
    //     } catch (error) {
    //       toast.error(
    //         error?.response?.data?.message ||
    //           "❌ Failed to add phlebotomist. Please try again."
    //       );
    //     } finally {
    //       setIsSubmitting(false);
    //     }
  };

  const createdBy = localStorage.getItem("role");
  // Validation patterns
  const alphaNumPattern = {
    value: /^[A-Za-z0-9 _-]+$/,
    message: "Only letters, numbers, spaces, - and _ are allowed",
  };

  const lettersOnlyPattern = {
    value: /^[A-Za-z ]+$/,
    message: "Only letters and spaces are allowed",
  };

  const fields = [
    {
      name: "searchuser",
      label: "Search User",
      placeholder: "Enter User Name",
      validation: {
        required: "Name is required",
        pattern: lettersOnlyPattern,
      },
    },
    {
      name: "hospitalselected",
      label: "Select Hospital",
      type: "select",
      options: hospitalsList,
      validation: { required: "Hospital is required" },
    },

    {
      name: "nodalselected",
      label: "Select Nodal",
      type: "select",
      options: nodalsList,
      validation: { required: "Nodal is required" },
    },
    {
      name: "selectedroll",
      label: "Select Role",
      type: "select",
      options: rolesList,
      validation: { required: "Role is required" },
    },

    {
      name: "createdby",
      label: "Created By",
      type: "text",
      placeholder: createdBy,
      validation: {
        required: "PIN Code is required",
        pattern: {
          value: /^\d{6}$/,
          message: "PIN must be exactly 6 digits",
        },
      },
    },

    {
      name: "loginid",
      label: "Login ID",
      type: "text",
      placeholder: "Enter LOgin ID",
      validation: {
        required: "PIN Code is required",
        pattern: {
          value: /^\d{6}$/,
          message: "PIN must be exactly 6 digits",
        },
      },
    },

    {
      name: "pincode",
      label: "Password",
      type: "text",
      placeholder: "Enter Password",
      validation: {
        required: "PIN Code is required",
        pattern: {
          value: /^\d{6}$/,
          message: "PIN must be exactly 6 digits",
        },
      },
    },

    {
      name: "dob",
      label: "Created Date",
      type: "date",
      validation: { required: "Date of birth is required" },
      max: today, // restrict to today or past
    },

    {
      name: "isactive",
      label: "Is Active?",
      type: "radio",
      options: [
        { value: "true", label: "Yes" },
        { value: "false", label: "No" },
      ],
      validation: { required: "Status is required." },
    },
  ];

  return (
    <>
      {/* Breadcrumb */}
      <div className="fixed top-[61px] w-full z-10">
        <nav
          className="flex items-center font-medium justify-start px-4 py-2 bg-gray-50 border-b shadow-lg transition-colors"
          aria-label="Breadcrumb"
        >
          <ol className="inline-flex items-center space-x-1 md:space-x-3 text-sm font-medium">
            <li>
              <Link
                to="/"
                className="inline-flex items-center text-gray-700 hover:text-teal-600 transition-colors"
              >
                🏠︎ Home
              </Link>
            </li>
            <li className="text-gray-400">/</li>
            <li>
              <Link
                to="/view-user-list"
                className="text-gray-700 hover:text-teal-600 transition-colors"
              >
                User Details
              </Link>
            </li>
            <li className="text-gray-400">/</li>
            <li aria-current="page" className="text-gray-500">
              Add User Mapping
            </li>
          </ol>
        </nav>
      </div>

      <div className="w-full mt-14 px-0 sm:px-2 space-y-4 text-sm">
        <ToastContainer />
        {fetchError && (
          <p className="text-red-500 text-sm mb-4">{fetchError}</p>
        )}

        <form
          onSubmit={handleSubmit(onSubmit)}
          className="bg-white shadow-lg rounded-xl overflow-hidden border border-gray-200"
        >
          <div className="border-b border-gray-200 px-6 py-4 bg-gradient-to-r from-teal-600 to-teal-500">
            <h4 className="font-semibold text-white">Add User Mapping</h4>
          </div>

          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {fields.map(
                ({
                  name,
                  label,
                  placeholder,
                  type = "text",
                  options,
                  validation,
                  max,
                }) => (
                  <div key={name} className="space-y-1">
                    <label className="block text-sm font-medium text-gray-700">
                      {label}{" "}
                      {validation?.required && (
                        <span className="text-red-500">*</span>
                      )}
                    </label>

                    {type === "select" ? (
                      <select
                        {...register(name, validation)}
                        onBlur={() => trigger(name)}
                        className={`w-full px-4 py-2 rounded-lg border ${
                          errors[name]
                            ? "border-red-500 focus:ring-red-500"
                            : "border-gray-300 focus:ring-teal-500"
                        } focus:ring-2 transition`}
                      >
                        <option value="">Select {label}</option>
                        {options.map((opt) => (
                          <option key={opt.value} value={opt.value}>
                            {opt.label}
                          </option>
                        ))}
                      </select>
                    ) : type === "radio" ? (
                      <div className="flex space-x-4 pt-2">
                        {options.map((opt) => (
                          <label
                            key={opt.value}
                            className="inline-flex items-center"
                          >
                            <input
                              type="radio"
                              {...register(name, validation)}
                              value={opt.value}
                              className="h-4 w-4 text-teal-600"
                            />
                            <span className="ml-2">{opt.label}</span>
                          </label>
                        ))}
                      </div>
                    ) : (
                      <input
                        type={type}
                        {...register(name, validation)}
                        onBlur={() => trigger(name)}
                        placeholder={placeholder}
                        max={max}
                        className={`w-full px-4 py-2 rounded-lg border ${
                          errors[name]
                            ? "border-red-500 focus:ring-red-500"
                            : "border-gray-300 focus:ring-teal-500"
                        } focus:ring-2 transition`}
                      />
                    )}

                    {errors[name] && (
                      <p className="text-red-500 text-xs mt-1">
                        {errors[name]?.message}
                      </p>
                    )}
                  </div>
                )
              )}
            </div>

            <div className="mt-6 flex justify-end">
              <button
                type="submit"
                disabled={isSubmitting}
                className="bg-teal-600 hover:bg-teal-700 text-white font-semibold px-6 py-2 rounded-md transition disabled:opacity-60"
              >
                {isSubmitting ? "Submitting..." : "Add User Mapping"}
              </button>
            </div>
          </div>
        </form>
      </div>
    </>
  );
};

export default AddUserMapping;
