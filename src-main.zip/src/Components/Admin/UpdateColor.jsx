import { useContext, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import AdminContext from "../../context/adminContext";

const UpdateColor = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { colorToUpdate, setColorToUpdate } = useContext(AdminContext);
  const navigate = useNavigate();

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    trigger,
  } = useForm({
    mode: "onBlur",
    defaultValues: {
      color_name: "",
      color_status: "",
    },
  });

  // Populate form when component mounts
  useEffect(() => {
    if (!colorToUpdate) return navigate("/view-color"); // Redirect if no color to update

    reset({
      color_name: colorToUpdate.colorcode?.name || "",
      color_status: colorToUpdate.colorstatus || "#000000",
    });
  }, [colorToUpdate, navigate, reset]);

  const onSubmit = async (formData) => {
    setIsSubmitting(true);
  
    try {
      const token = localStorage.getItem("authToken");
  
      const payload = {
        colorstatus: formData.color_status,
        colorname: formData.color_name.trim(),
        colorcode: {
          hex: formData.color_status,
          rgb: hexToRgb(formData.color_status),
          hsl: hexToHsl(formData.color_status),
        },
      };
  
      console.log("Update Payload:", payload);
  
      await axios.put(
        `https://asrlabs.asrhospitalindia.in/api/lims/master/colors/${colorToUpdate.id}`,
        payload,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
  
      toast.success("Color updated successfully!");
      setColorToUpdate(null);
      navigate("/view-color");
    } catch (error) {
      console.error("Update failed:", error);
      toast.error(error.response?.data?.message || "❌ Failed to update color.");
    } finally {
      setIsSubmitting(false);
    }
  };
  

  const fields = [
    {
      name: "color_name",
      label: "Color Name",
      placeholder: "e.g., Red",
      validation: {
        required: "Color name is required",
        pattern: {
          value: /^[A-Za-z\s]+$/i,
          message: "Only alphabets allowed",
        },
      },
    },
    {
      name: "color_status",
      label: "Color Code",
      placeholder: "#ff0000",
      validation: {
        required: "Color code is required",
        pattern: {
          value: /^#([0-9A-Fa-f]{3}){1,2}$/,
          message: "Must be a valid hex code",
        },
      },
    },
  ];

  return (
    <div className="container max-w-7xl mx-auto w-full mt-6 px-2 sm:px-4 text-sm">
      <ToastContainer />
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="bg-white shadow-lg rounded-xl overflow-hidden border border-gray-200"
      >
        <div className="border-b border-gray-200 px-6 py-4 bg-gradient-to-r from-teal-600 to-teal-500">
          <h4 className="font-semibold text-white">Update Color</h4>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {fields.map(({ name, label, placeholder, validation }) => (
              <div key={name} className="space-y-1">
                <label className="block text-sm font-medium text-gray-700">
                  {label}{" "}
                  {validation?.required && (
                    <span className="text-red-500">*</span>
                  )}
                </label>

                <input
                  type={name === "color_status" ? "color" : "text"}
                  {...register(name, validation)}
                  onBlur={() => trigger(name)}
                  placeholder={placeholder}
                  className={`w-full px-4 py-2 rounded-lg border ${
                    errors[name]
                      ? "border-red-500 focus:ring-red-500"
                      : "border-gray-300 focus:ring-teal-500"
                  } focus:ring-2 focus:border-transparent transition`}
                />

                {errors[name] && (
                  <p className="text-red-500 text-xs mt-1">
                    {errors[name].message}
                  </p>
                )}
              </div>
            ))}
          </div>

          <div className="mt-8 flex justify-end">
            <button
              type="button"
              onClick={() => reset()}
              className="mr-4 px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition"
            >
              Reset
            </button>

            <button
              type="submit"
              disabled={isSubmitting}
              className={`px-6 py-2 ${
                isSubmitting
                  ? "bg-gray-400 cursor-not-allowed"
                  : "bg-gradient-to-r from-teal-600 to-teal-500 hover:from-teal-700 hover:to-teal-600"
              } text-white rounded-lg shadow-md transition-all duration-300 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-opacity-50`}
            >
              {isSubmitting ? "Updating..." : "Update Color"}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default UpdateColor;
